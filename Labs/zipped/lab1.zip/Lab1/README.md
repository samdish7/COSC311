# Lab 1 README

## Program Description

This program demonstrates basic python oeprations and list comprehension. 

I documented all my answers and the numbers each cell corresponds to. 

### Number 11

a&b) One way I would make this visual is similar to what Spotify does. Using the key\_words tuple can help our database find certain song types that people like. To make it look good, with each data value in the returned list, add visuals such as a picture for the songs, how much time is left and total time the song takes, and various other eye candies. One application that could do this job is vpython.

c) I would absolutely use the keywords tuple to base my algorithm around. If someone likes rock music, then have python do a search for the keyword "rock" and display some songs/artists that write that type of music.
